import React from 'react';
import TopBar from './TopBar';
import Footer from './Footer';
import './Home.css'; // You can style your components with CSS
import './MainPage'; // You can style your components with CSS

function Submitted() {
  return (
    <div className="app">
      <TopBar />
      <div className="mainpage">
      <div className="main-content">
       Excellent! <br/> See you in November 2023!
      </div>
    </div>
      <Footer />
    </div>
  );
}

export default Submitted;