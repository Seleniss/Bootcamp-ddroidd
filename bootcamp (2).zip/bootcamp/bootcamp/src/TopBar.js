// TopBar.js
import React from 'react';
import './TopBar.css';

function TopBar() {
  return (
    // <div className="topbar">
    //     <img className="logo" alt='' src="./assets/img/ddroidd_logo.svg"></img>
    // </div>
     <div className="topbar">
      <div className="left">
       <img className="logo" alt='' src="./assets/img/ddroidd_logo.svg"></img>
      </div>
      <div className="center">
        <div className="text">Autumn - Winter Bootcamp</div>
      </div>
      <div className="right">
        <button className="button">Join Us</button>
      </div>
    </div>
  );
}

export default TopBar;
