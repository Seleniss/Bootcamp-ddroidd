import React from 'react';
import { useNavigate } from 'react-router-dom';
import './MainPage.css';

function MainPage() {
     const navigate = useNavigate();

return (
    <div className="mainpage">
      <div className="main-content">
        <div className="image-container">
            <img src="./assets/img/destructuring.svg" className="image" />
            <img src="./assets/img/WebPage_logo.svg" className="image" />
        </div>
        <div className="button-container">
          <button className="centered-button" onClick={() => navigate('/form')}>Join Us</button>
        </div>
      </div>
    </div>
  );
}

export default MainPage;
