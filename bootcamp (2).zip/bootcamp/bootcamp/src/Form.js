import React, { useState, useEffect } from "react";
import { useNavigate } from 'react-router-dom';
import Footer from "./Footer";
import TopBar from './TopBar';
import './Form.css'; 

function Form() {
   const navigate = useNavigate();

  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    phoneNumber: "",
    email: "",
    addressLine1: "",
    addressLine2: "",
    country: "",
    state: "",
    city: "",
  });

  const [countries, setCountries] = useState([]);
  const [states, setStates] = useState([]);
  const [cities, setCities] = useState([]);

  const [errors, setErrors] = useState({
    firstName: "",
    lastName: "",
    phoneNumber: "",
    email: "",
    addressLine1: "",
    addressLine2: "",
    country: "",
    state: "",
    city: "",
  });

  console.log(Object.values(errors).reduce((count, obj) => {
  const nonEmptyValues = Object.values(obj).filter(value => value !== "");
  return count + nonEmptyValues.length;
}, 0))

   useEffect(() => {
    // Fetch the list of countries from your API and set it in the "countries" state.
    // Example API call:
    fetch("https://countriesnow.space/api/v0.1/countries")
      .then((response) => response.json())
      .then((data) => setCountries(data?.data?.map(country => country.country)));
  }, []);

  const handleCountryChange = (e) => {
    const selectedCountry = e.target.value;
    console.log(selectedCountry)
    if(selectedCountry){
    setFormData({
      ...formData,
      country: selectedCountry,
      state: "",
      city: "",
    });

    // Fetch the list of states for the selected country from your API
    // and set it in the "states" state.
    // Example API call:
     const requestOptions = {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ country: selectedCountry })
    };

    fetch(`https://countriesnow.space/api/v0.1/countries/states`, requestOptions)
      .then((response) => response.json())
      .then((data) => setStates(data?.data?.states?.map(x=>x.name)));
  };}

  const handleStateChange = (e) => {
    const selectedState = e.target.value;
     if(selectedState){
    setFormData({
      ...formData,
      state: selectedState,
      city: "",
    });

     const requestOptions = {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ country: formData.country, state: selectedState })
    };

    // Fetch the list of cities for the selected state from your API
    // and set it in the "cities" state.
    // Example API call:
    fetch(`https://countriesnow.space/api/v0.1/countries/state/cities`, requestOptions)
      .then((response) => response.json())
      .then((data) => setCities(data?.data));
  }
  };

  const validateForm = () => {
    let valid = true;
    const newErrors = {};

    if (formData.firstName.trim() === "") {
      newErrors.firstName = "First name is required";
      valid = false;
    }

    if (formData.lastName.trim() === "") {
      newErrors.lastName = "Last name is required";
      valid = false;
    }

    if (formData.phoneNumber.trim() === "") {
      newErrors.phoneNumber = "phoneNumber is required";
      valid = false;
    }

    if (formData.email.trim() === "") {
      newErrors.email = "email is required";
      valid = false;
    }
    if (formData.addressLine1.trim() === "") {
      newErrors.addressLine1 = "addressLine1 is required";
      valid = false;
    }

    if (formData.addressLine2.trim() === "") {
      newErrors.addressLine2 = "addressLine2 is required";
      valid = false;
    }

    if (formData.country.trim() === "") {
      newErrors.country = "country is required";
      valid = false;
    }
    if (formData.state.trim() === "") {
      newErrors.state = "state is required";
      valid = false;
    }

    if (formData.city.trim() === "") {
      newErrors.city = "city is required";
      valid = false;
    }

    setErrors(newErrors);
    return valid;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    console.log(errors)
    if (validateForm()) {
      // Handle form submission here
      console.log("Form submitted:", formData);
      navigate("/submitted")
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  return (
    <div className="app">
      <TopBar />
     <div className="mainpage">
      <div className="main-content">
      <form onSubmit={handleSubmit}>
        <div>
          <label htmlFor="firstName">First Name</label>
          <input
            type="text"
            id="firstName"
            name="firstName"
            value={formData.firstName}
            onChange={handleChange}
            className={errors.firstName ? "error" : ""}
          />
          {errors.firstName && <span className="error-message">{errors.firstName}</span>}
        </div>
        <div>
          <label htmlFor="lastName">Last Name</label>
          <input
            type="text"
            id="lastName"
            name="lastName"
            value={formData.lastName}
            onChange={handleChange}
            className={errors.lastName ? "error" : ""}
          />
          {errors.lastName && <span className="error-message">{errors.lastName}</span>}
        </div>
        <div>
          <label htmlFor="phoneNumber">Phone Number</label>
          <input
            type="text"
            id="phoneNumber"
            name="phoneNumber"
            value={formData.firstphoneNumberName}
            onChange={handleChange}
            className={errors.phoneNumber ? "error" : ""}
          />
          {errors.phoneNumber && <span className="error-message">{errors.phoneNumber}</span>}
        </div>
        <div>
          <label htmlFor="email">Email</label>
          <input
            type="text"
            id="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
            className={errors.email ? "error" : ""}
          />
          {errors.email && <span className="error-message">{errors.email}</span>}
        </div>
        <div>
          <label htmlFor="addressLine1">Address Line 1</label>
          <input
            type="text"
            id="addressLine1"
            name="addressLine1"
            value={formData.addressLine1}
            onChange={handleChange}
            className={errors.addressLine1 ? "error" : ""}
          />
          {errors.addressLine1 && <span className="error-message">{errors.addressLine1}</span>}
        </div>
        <div>
          <label htmlFor="addressLine2">Address Line 2</label>
          <input
            type="text"
            id="addressLine2"
            name="addressLine2"
            value={formData.addressLine2}
            onChange={handleChange}
            className={errors.addressLine2 ? "error" : ""}
          />
          {errors.addressLine2 && <span className="error-message">{errors.addressLine2}</span>}
        </div>
        <div>
          <label htmlFor="country">Country</label>
          <select
            id="country"
            name="country"
            value={formData.country}
            onChange={handleCountryChange}
            className={errors.country ? "error" : ""}
          >
            <option value="">Select Country</option>
            {countries?.map((country) => (
              <option key={country} value={country}>
                {country}
              </option>
            ))}
          </select>
          {errors.country && <span className="error-message">{errors.country}</span>}
        </div>
        <div>
          <label htmlFor="state">State</label>
          <select
            id="state"
            name="state"
            value={formData.state}
            onChange={handleStateChange}
            className={errors.state ? "error" : ""}
          >
            <option value="">Select State</option>
            {states?.map((state) => (
              <option key={state} value={state}>
                {state}
              </option>
            ))}
          </select>
           {errors.state && <span className="error-message">{errors.state}</span>}
        </div>
        <div>
          <label htmlFor="city">City</label>
          <select id="city" name="city" value={formData.city} className={errors.city ? "error" : ""} onChange={(e) => setFormData({ ...formData, city: e.target.value })}>
            <option value="">Select City</option>
            {cities?.map((city) => (
              <option key={city} value={city}>
                {city}
              </option>
            ))}
          </select>
           {errors.city && <span className="error-message">{errors.city}</span>}
        </div>
        <button type="submit">Join Us</button>
      </form>
      {errors && Object.values(errors).reduce((count, obj) => {
  const nonEmptyValues = Object.values(obj).filter(value => value !== "");
  return count + nonEmptyValues.length;
}, 0) > 0 && (
        <div className="error-list">
          <h3>Validation Errors:</h3>
          <ul>
            {Object.values(errors).map((error, index) => (
              <li key={index}>{error}</li>
            ))}
          </ul>
        </div>
      )}
    </div>
    </div>
    <Footer/>
    </div>
  );
}

export default Form;