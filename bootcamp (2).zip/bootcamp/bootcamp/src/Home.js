import React from 'react';
import TopBar from './TopBar';
import MainPage from './MainPage';
import Footer from './Footer';
import './Home.css'; // You can style your components with CSS

function Home() {
  return (
    <div className="app">
      <TopBar />
      <MainPage />
      <Footer />
    </div>
  );
}

export default Home;