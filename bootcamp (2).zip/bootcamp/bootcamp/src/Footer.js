import React from 'react';
import './Footer.css';

function Footer() {
  return (
    <div className="footer">
      Come to the dark side... we have cookies
    </div>
  );
}

export default Footer;
