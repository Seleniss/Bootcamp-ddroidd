// App.js
import { Routes, Route } from 'react-router-dom';
import Home from './/Home';
import Form from './Form';
import Submitted from './Submitted';

const App = () => {
 return (
    <>
       <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/form" element={<Form />} />
          <Route path="/submitted" element={<Submitted />} />
       </Routes>
    </>
 );
};

export default App;